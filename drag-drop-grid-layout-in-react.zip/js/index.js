var _slicedToArray = function () {function sliceIterator(arr, i) {var _arr = [];var _n = true;var _d = false;var _e = undefined;try {for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {_arr.push(_s.value);if (i && _arr.length === i) break;}} catch (err) {_d = true;_e = err;} finally {try {if (!_n && _i["return"]) _i["return"]();} finally {if (_d) throw _e;}}return _arr;}return function (arr, i) {if (Array.isArray(arr)) {return arr;} else if (Symbol.iterator in Object(arr)) {return sliceIterator(arr, i);} else {throw new TypeError("Invalid attempt to destructure non-iterable instance");}};}();var dataStructure = [// structure that models our initial rendered view of items
[0, 1, 2],
[3, 4, 5, 6, 7],
[8, 9, 10, 11]];


var reinsert = function reinsert(array, colFrom, rowFrom, colTo, rowTo) {
    var _array = array.slice(0);
    var val = _array[colFrom][rowFrom];
    _array[colFrom].splice(rowFrom, 1);
    _array[colTo].splice(rowTo, 0, val);
    calculateVisiblePositions(_array);
    return _array;
};

var gutterPadding = 21;
var clamp = function clamp(n, min, max) {return Math.max(Math.min(n, max), min);};
var getColumnWidth = function getColumnWidth() {return window.innerWidth / dataStructure.length - gutterPadding / dataStructure.length;}; // spread columns over available window width
var height = 110; // crappy fixed item height :(

var width = getColumnWidth(),
layout = null;

// items are ordered by their index in this visual positions array
var calculateVisiblePositions = function calculateVisiblePositions(newOrder) {
    width = getColumnWidth();
    layout = newOrder.map(function (column, col) {
        return _.range(column.length + 1).map(function (item, row) {
            return [width * col, height * row];
        });
    });
};

// define spring motion opts
var springSetting1 = { stiffness: 180, damping: 10 };
var springSetting2 = { stiffness: 150, damping: 16 };

var List = React.createClass({ displayName: 'List',
    getInitialState: function getInitialState() {
        return {
            mouse: [0, 0],
            delta: [0, 0], // difference between mouse and item position, for dragging
            lastPress: null, // key of the last pressed component
            currentColumn: null,
            isPressed: false,
            order: dataStructure, // index: visual position. value: component key/id
            isResizing: false };

    },

    componentWillMount: function componentWillMount() {
        this.resizeTimeout = null;
        calculateVisiblePositions(dataStructure);
    },

    componentDidMount: function componentDidMount() {
        window.addEventListener('touchmove', this.handleTouchMove);
        window.addEventListener('mousemove', this.handleMouseMove);
        window.addEventListener('touchend', this.handleMouseUp);
        window.addEventListener('mouseup', this.handleMouseUp);
        window.addEventListener('resize', this.handleResize);
    },

    componentWillUnmount: function componentWillUnmount() {
        window.removeEventListener('resize', this.handleResize);
    },

    handleTouchStart: function handleTouchStart(key, currentColumn, pressLocation, e) {
        this.handleMouseDown(key, currentColumn, pressLocation, e.touches[0]);
    },

    handleTouchMove: function handleTouchMove(e) {
        e.preventDefault();
        this.handleMouseMove(e.touches[0]);
    },

    handleMouseMove: function handleMouseMove(_ref) {var pageX = _ref.pageX,pageY = _ref.pageY;var _state =
        this.state,order = _state.order,lastPress = _state.lastPress,colFrom = _state.currentColumn,isPressed = _state.isPressed,_state$delta = _slicedToArray(_state.delta, 2),dx = _state$delta[0],dy = _state$delta[1];
        if (isPressed) {
            var mouse = [pageX - dx, pageY - dy];
            var colTo = clamp(Math.floor((mouse[0] + width / 2) / width), 0, 2);
            var rowTo = clamp(Math.floor((mouse[1] + height / 2) / height), 0, 100);
            var rowFrom = order[colFrom].indexOf(lastPress);
            var newOrder = reinsert(order, colFrom, rowFrom, colTo, rowTo);
            this.setState({
                mouse: mouse,
                order: newOrder,
                currentColumn: colTo });

        }
    },

    handleMouseDown: function handleMouseDown(key, currentColumn, _ref2, _ref3) {var _ref4 = _slicedToArray(_ref2, 2),pressX = _ref4[0],pressY = _ref4[1];var pageX = _ref3.pageX,pageY = _ref3.pageY;
        this.setState({
            lastPress: key,
            currentColumn: currentColumn,
            isPressed: true,
            delta: [pageX - pressX, pageY - pressY],
            mouse: [pressX, pressY] });

    },

    handleMouseUp: function handleMouseUp() {
        this.setState({
            isPressed: false,
            delta: [0, 0] });

    },

    handleResize: function handleResize() {var _this = this;
        clearTimeout(this.resizeTimeout);
        this.applyResizingState(true);
        // resize one last time after resizing stops, as sometimes this can be a little janky sometimes...
        this.resizeTimeout = setTimeout(function () {return _this.applyResizingState(false);}, 100);
    },

    applyResizingState: function applyResizingState(isResizing) {
        this.setState({ isResizing: isResizing });
        calculateVisiblePositions(dataStructure);
    },

    render: function render() {var _this2 = this;var _state2 =
        this.state,order = _state2.order,lastPress = _state2.lastPress,currentColumn = _state2.currentColumn,isPressed = _state2.isPressed,mouse = _state2.mouse,isResizing = _state2.isResizing;
        return (
            React.createElement('div', { className: 'items' },
                order.map(function (column, colIndex) {
                    return (
                        column.map(function (row) {
                            var style = void 0,
                            x = void 0,
                            y = void 0,
                            visualPosition = order[colIndex].indexOf(row),
                            isActive = row === lastPress && colIndex === currentColumn && isPressed;

                            if (isActive) {var _mouse = _slicedToArray(
                                mouse, 2);x = _mouse[0];y = _mouse[1];
                                style = {
                                    translateX: x,
                                    translateY: y,
                                    scale: ReactMotion.spring(1.1, springSetting1) };

                            } else if (isResizing) {var _layout$colIndex$visu = _slicedToArray(
                                layout[colIndex][visualPosition], 2);x = _layout$colIndex$visu[0];y = _layout$colIndex$visu[1];
                                style = {
                                    translateX: x,
                                    translateY: y,
                                    scale: 1 };

                            } else {var _layout$colIndex$visu2 = _slicedToArray(
                                layout[colIndex][visualPosition], 2);x = _layout$colIndex$visu2[0];y = _layout$colIndex$visu2[1];
                                style = {
                                    translateX: ReactMotion.spring(x, springSetting2),
                                    translateY: ReactMotion.spring(y, springSetting2),
                                    scale: ReactMotion.spring(1, springSetting1) };

                            }

                            return (
                                React.createElement(ReactMotion.Motion, { key: row, style: style },
                                    function (_ref5) {var translateX = _ref5.translateX,translateY = _ref5.translateY,scale = _ref5.scale;return (
                                            React.createElement('div', {
                                                    onMouseDown: _this2.handleMouseDown.bind(null, row, colIndex, [x, y]),
                                                    onTouchStart: _this2.handleTouchStart.bind(null, row, colIndex, [x, y]),
                                                    className: isActive ? 'item is-active' : 'item',
                                                    style: {
                                                        WebkitTransform: 'translate3d(' + translateX + 'px, ' + translateY + 'px, 0) scale(' + scale + ')',
                                                        transform: 'translate3d(' + translateX + 'px, ' + translateY + 'px, 0) scale(' + scale + ')',
                                                        zIndex: row === lastPress && colIndex === currentColumn ? 99 : visualPosition } }, 'Item ',
                                                row + 1));}));



                        }));

                })));


    } });


ReactDOM.render(React.createElement(List, null), document.getElementById('react-root'));